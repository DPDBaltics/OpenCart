<?php
$_['heading_title']	=	'Naudas iekasēšanas piegādes brīdī (Cash on Delivery - COD) piemaksa';
$_['text_success']     = 'COD piemaksa ir veiksmīgi iestatīta!';
$_['text_edit'] = 'Mainīt naudas iekasēšanas (COD) piemaksu';
$_['entry_status']	=	'COD piemaksa ir:<span data-toggle="tooltip" title="" data-original-title="Ja COD piemaksa ir aktivizēta, tas nozīmē, ka tā tiks uzrādīta preču grozā, kontā. Taču, lai to varētu piemērot, ir jāaktivizē arī pats maksājuma veids - naudas iekasēšana piegādes brīdī (COD)." class="custom-tooltip"></span>';
$_['entry_sort_order'] = 'Secības prioritāte:';
$_['entry_cod_fee'] = 'COD piemaksa:';
$_['entry_tax_class']        = 'Nodokļu veids';