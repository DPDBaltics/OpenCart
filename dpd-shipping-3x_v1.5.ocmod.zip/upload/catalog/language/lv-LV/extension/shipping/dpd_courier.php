<?php
// Text
$_['text_title_sat'] = '<img src="admin/view/image/dpd_logo.png" title="DPD Piegāde ar kurjeru" alt="DPD Piegāde ar kurjeru" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Piegāde ar kurjeru sestdienā';
$_['text_title']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Piegāde ar kurjeru" alt="DPD Piegāde ar kurjeru" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Piegāde ar kurjeru';

$_['text_title_logo']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Piegāde ar kurjeru" alt="DPD Piegāde ar kurjeru" style="height: 30px; margin-right: 15px; vertical-align: bottom;" />';
$_['text_title_sat']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Piegāde ar kurjeru" alt="DPD Piegāde ar kurjeru" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Piegāde ar kurjeru sestdienā';
$_['text_title_same']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Piegāde ar kurjeru" alt="DPD Piegāde ar kurjeru" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Same Day Piegāde ar kurjeru';

$_['text_additional_shipping_title'] = 'DPD piegāde ar kurjeru';
$_['text_additional_shipping_title_sat'] = 'DPD piegāde ar kurjeru sestdienā';
$_['text_additional_shipping_title_same'] = 'DPD Same Day piegāde ar kurjeru';
$_['text_weight'] = 'Svars:';
$_['text_free_shipping'] = 'BEZMAKSAS PIEGĀDE';
$_['text_pickup_time'] = 'Izvēlieties piegādes laika intervālu:';