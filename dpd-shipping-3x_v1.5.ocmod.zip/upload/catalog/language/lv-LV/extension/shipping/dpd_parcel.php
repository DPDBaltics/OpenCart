<?php
// Text
$_['text_title']  = '<img src="admin/view/image/dpd_pickup_logo.jpg" title="DPD Pickup punkti (Paku Skapji un Paku Bodes)" alt="DPD Pickup punkti (Paku Skapji un Paku Bodes)" style="height: 50px; margin-right: 15px;"> DPD Pickup punkti (Paku Skapji un Paku Bodes)';
$_['text_additional_shipping_title'] = 'Piegāde uz DPD Pickup punktiem (Paku Skapjiem un Paku Bodēm)';
$_['text_weight'] = 'Svars:';
$_['text_free_shipping'] = 'BEZMAKSAS PIEGĀDE';
$_['text_pick_parcel'] = 'Izvēlieties Pickup punktu';

$_['text_modal_show'] = 'Rādīt Pickup punktus';
$_['text_modal_search'] = 'Meklēt';
$_['text_modal_address'] = 'Adrese';
$_['text_modal_city'] = 'Pilsēta';
$_['text_modal_info_address'] = 'Adrese';
$_['text_modal_info_hours'] = 'Darba laiks';
$_['text_modal_info_contact'] = 'Kontakti';
$_['text_modal_info_select'] = 'Izvēlēties';
$_['text_no_parcel_selected'] = 'UZMANĪBU: Jūs neesat izvēlējies nevienu Pickup punktu.';

$_['text_day_mon'] = 'Pirmdiena:';
$_['text_day_tue'] = 'Otrdiena:';
$_['text_day_wed'] = 'Trešdiena:';
$_['text_day_thu'] = 'Ceturtdiena:';
$_['text_day_fri'] = 'Piektdiena:';
$_['text_day_sat'] = 'Sestdiena:';
$_['text_day_sun'] = 'Svētdiena:';