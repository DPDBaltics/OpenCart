<?php
// Text
$_['text_title_sat'] = '<img src="admin/view/image/dpd_logo.png" title="DPD kurjeris" alt="DPD kurjeris" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD kurjeris šeštadienį';
$_['text_title']  = '<img src="admin/view/image/dpd_logo.png" title="DPD kurjeris" alt="DPD kurjeris" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD kurjeris';

$_['text_title_logo']  = '<img src="admin/view/image/dpd_logo.png" title="DPD kurjeris" alt="DPD kurjeris" style="height: 30px; margin-right: 15px; vertical-align: bottom;" />';
$_['text_title_sat']  = '<img src="admin/view/image/dpd_logo.png" title="DPD kurjeris" alt="DPD kurjeris" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD kurjeris šeštadienį';
$_['text_title_same']  = '<img src="admin/view/image/dpd_logo.png" title="DPD kurjeris" alt="DPD kurjeris" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD kurjeris tą pačią dieną';

$_['text_additional_shipping_title'] = 'Pristatymas į rankas per DPD kurjerį';
$_['text_additional_shipping_title_sat'] = 'Pristatymas į rankas šeštadienį per DPD kurjerį';
$_['text_additional_shipping_title_same'] = 'Pristatymas į rankas tą pačią dieną per DPD kurjerį';
$_['text_weight'] = 'Svoris:';
$_['text_free_shipping'] = 'Nemokamas pristatymas';
$_['text_pickup_time'] = 'Pasirinkite pristatymo laiką:';