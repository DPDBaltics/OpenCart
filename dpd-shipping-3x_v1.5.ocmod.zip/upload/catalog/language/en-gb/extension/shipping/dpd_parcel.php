<?php
// Text
$_['text_title']  = '<img src="admin/view/image/dpd_pickup_logo.jpg" title="DPD Parcel store" alt="DPD Parcel store" style="height: 50px; margin-right: 15px;"> DPD Pickup points';
$_['text_additional_shipping_title'] = 'Shipping by DPD Pickup points';
$_['text_weight'] = 'Weight:';
$_['text_free_shipping'] = 'FREE SHIPPING';
$_['text_pick_parcel'] = 'Pick parcel store';

$_['text_modal_show'] = 'Show parcel stores';
$_['text_modal_search'] = 'Search';
$_['text_modal_address'] = 'Address';
$_['text_modal_city'] = 'City';
$_['text_modal_info_address'] = 'Address';
$_['text_modal_info_hours'] = 'Working hours';
$_['text_modal_info_contact'] = 'Contact';
$_['text_modal_info_select'] = 'Select';
$_['text_no_parcel_selected'] = 'Warning: Parcel not selected';

$_['text_day_mon'] = 'Monday:';
$_['text_day_tue'] = 'Thusday:';
$_['text_day_wed'] = 'Wednesday:';
$_['text_day_thu'] = 'Thursday:';
$_['text_day_fri'] = 'Friday:';
$_['text_day_sat'] = 'Saturday:';
$_['text_day_sun'] = 'Sunday:';