<?php
$_['text_cod_fee'] = 'COD Fee';