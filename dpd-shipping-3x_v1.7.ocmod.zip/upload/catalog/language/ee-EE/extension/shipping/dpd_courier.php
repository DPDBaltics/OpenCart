<?php
// Text
$_['text_title_sat'] = '<img src="admin/view/image/dpd_logo.png" title="DPD Kuller" alt="DPD Kuller" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> Laupäeva teenus DPD kulleriga';
$_['text_title']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Kuller" alt="DPD Kuller" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Kuller';

$_['text_title_logo']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Kuller" alt="DPD Kuller" style="height: 30px; margin-right: 15px; vertical-align: bottom;" />';
$_['text_title_sat']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Kuller" alt="DPD Kuller" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> Laupäeva teenus DPD kulleriga';
$_['text_title_same']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Kuller" alt="DPD Kuller" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> Sama päeva tarne DPD kulleriga';

$_['text_additional_shipping_title'] = 'DPD Kuller';
$_['text_additional_shipping_title_sat'] = 'Laupäeva teenus DPD kulleriga';
$_['text_additional_shipping_title_same'] = 'Sama päeva tarne DPD kulleriga';
$_['text_weight'] = 'Kaal:';
$_['text_free_shipping'] = 'Tasuta saatmine';
$_['text_pickup_time'] = 'Vali kohaletoimetamise aeg:';