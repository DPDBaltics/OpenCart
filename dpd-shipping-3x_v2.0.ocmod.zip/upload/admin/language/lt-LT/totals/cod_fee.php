<?php
$_['heading_title']	=	'Cash On Delivery (COD) Fee';
$_['text_success']     = 'Success: You have modified COD Fee!';
$_['text_edit'] = 'Edit Cash On Delivery (COD) Fee';
$_['entry_status']	=	'COD payment during the delivery fee is:<span data-toggle="tooltip" title="" data-original-title="If payment during the delivery fee rendering is Enabled, it means that it will appear in product basket, account. In order to it be visible in account, payment method - Payment at delivery time must be activated." class="custom-tooltip"></span>';
$_['entry_sort_order'] = 'Sort order:';
$_['entry_cod_fee'] = 'COD Fee:';
$_['entry_tax_class']        = 'Tax Class';