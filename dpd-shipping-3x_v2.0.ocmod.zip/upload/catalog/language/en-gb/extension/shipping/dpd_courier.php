<?php
// Text
$_['text_title_sat'] = '<img src="admin/view/image/dpd_logo.png" title="DPD Courier shipping" alt="DPD Courier shipping" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Courier Saturday delivery';
$_['text_title']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Courier shipping" alt="DPD Courier shipping" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Courier shipping';

$_['text_title_logo']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Courier shipping" alt="DPD Courier shipping" style="height: 30px; margin-right: 15px; vertical-align: bottom;" />';
$_['text_title_sat']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Courier shipping" alt="DPD Courier shipping" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Courier Saturday shipping';
$_['text_title_same']  = '<img src="admin/view/image/dpd_logo.png" title="DPD Courier shipping" alt="DPD Courier shipping" style="height: 30px; margin-right: 15px; vertical-align: bottom;" /> DPD Courier Same day shipping';

$_['text_additional_shipping_title'] = 'Shipping by DPD Courier';
$_['text_additional_shipping_title_sat'] = 'Shipping by DPD Courier on Saturday';
$_['text_additional_shipping_title_same'] = 'Shipping by DPD Courier at same day';
$_['text_weight'] = 'Weight:';
$_['text_free_shipping'] = 'FREE SHIPPING';
$_['text_pickup_time'] = 'Select delivery time:';