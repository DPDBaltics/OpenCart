<?php
$_['text_cod_fee'] = 'Maksa par naudas iekasēšanu (COD) piegādes brīdī';