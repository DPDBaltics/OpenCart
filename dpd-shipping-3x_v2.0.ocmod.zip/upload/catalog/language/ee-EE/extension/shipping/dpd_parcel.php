﻿<?php
// Text
$_['text_title']  = '<img src="admin/view/image/dpd_pickup_logo.jpg" title="DPD Parcel store" alt="DPD Pickup pakiautomaat ja pakipood" style="height: 50px; margin-right: 15px;"> DPD Pickup pakiautomaat ja pakipood';
$_['text_additional_shipping_title'] = 'DPD Pickup pakiautomaat ja pakipood';
$_['text_weight'] = 'Kaal:';
$_['text_free_shipping'] = 'TASUTA SAATMINE';
$_['text_pick_parcel'] = 'DPD Pickup pakiautomaat ja pakipood';

$_['text_modal_show'] = 'Näita DPD pakiautomaate ja pakipoode';
$_['text_modal_search'] = 'Otsi';
$_['text_modal_address'] = 'Aadress';
$_['text_modal_city'] = 'Linn';
$_['text_modal_info_address'] = 'Aadress';
$_['text_modal_info_hours'] = 'Tööaeg';
$_['text_modal_info_contact'] = 'Kontakt';
$_['text_modal_info_select'] = 'Vali';
$_['text_no_parcel_selected'] = 'Hoiatus: Pakki pole valitud';

$_['text_day_mon'] = 'Esmaspäev:';
$_['text_day_tue'] = 'Teisipäev:';
$_['text_day_wed'] = 'Kolmapäev:';
$_['text_day_thu'] = 'Neljapäev:';
$_['text_day_fri'] = 'Reede:';
$_['text_day_sat'] = 'Laupäev:';
$_['text_day_sun'] = 'Pühapäev:';