<?php
// Text
$_['text_title']  = '<img src="admin/view/image/dpd_pickup_logo.jpg" title="DPD Pickup taškas" alt="DPD Pickup taškas" style="height: 50px; margin-right: 15px;"> DPD Pickup tinklas';
$_['text_additional_shipping_title'] = 'Pristatymas į DPD Pickup tašką';
$_['text_weight'] = 'Svoris:';
$_['text_free_shipping'] = 'Nemokamas pristatymas';
$_['text_pick_parcel'] = 'Pasirinkti Pickup tašką';

$_['text_modal_show'] = 'Rodyti Pickup taškus';
$_['text_modal_search'] = 'Iešoti';
$_['text_modal_address'] = 'Adresas';
$_['text_modal_city'] = 'Miestas';
$_['text_modal_info_address'] = 'Adresas';
$_['text_modal_info_hours'] = 'Darbo valandos';
$_['text_modal_info_contact'] = 'Kontaktai';
$_['text_modal_info_select'] = 'Pasirinkti';
$_['text_no_parcel_selected'] = 'Dėmesio: nepasirinktas Pickup taškas!';

$_['text_day_mon'] = 'Pirmadienis:';
$_['text_day_tue'] = 'Antradienis:';
$_['text_day_wed'] = 'Trečadienis:';
$_['text_day_thu'] = 'Ketvirtadienis:';
$_['text_day_fri'] = 'Penktadienis:';
$_['text_day_sat'] = 'Šeštadienis:';
$_['text_day_sun'] = 'Sekmadienis:';