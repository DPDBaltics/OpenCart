<?php
$_['heading_title']    = '<img src="view/image/dpd_logo.png" title="DPD Saturday (courier)" alt="DPD Saturday (courier)" style="height: 22px; margin-right: 15px;" /> DPD Saturday (courier)';