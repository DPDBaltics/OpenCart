<?php
$_['heading_title'] = '<img src="view/image/dpd_logo.png" title="DPD Same day (courier)" alt="DPD Same day (courier)" style="height: 22px; margin-right: 15px;" /> DPD Same day (courier)';