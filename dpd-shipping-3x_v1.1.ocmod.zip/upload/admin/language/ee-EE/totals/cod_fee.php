<?php
$_['heading_title']	=	'Lunapaki (COD) lisatasu';
$_['text_success']     = 'COD lisatasu on edukalt muudetud!';
$_['text_edit'] = 'Muuda lunapaki (COD) lisatasu';
$_['entry_status']	=	'COD Lisatasu on:<span data-toggle="tooltip" title="" data-original-title="Kui COD lisatasu on lubatud siis lisatakse see COD maksemeetodi valimise puhul summale. Kassas kuvamiseks peab COD maksemeetod lubatud olema." class="custom-tooltip"></span>';
$_['entry_sort_order'] = 'Sorteerimisjärjekorra number:';
$_['entry_cod_fee'] = 'COD lisatasu:';
$_['entry_tax_class']        = 'Maksuklass';